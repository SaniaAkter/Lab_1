# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 22:27:49 2021

@author: supty
"""

list = [3,7,9,10,11,23,34]
total = sum(list)
print("The sum of the list:", total)