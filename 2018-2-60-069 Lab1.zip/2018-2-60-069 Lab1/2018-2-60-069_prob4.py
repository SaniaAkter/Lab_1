# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 20:33:48 2021

@author: supty
"""

n = int(input("Enter a positive integer number:"))

total = n * (n+1) / 2

print("value of the given series= ",n,total)