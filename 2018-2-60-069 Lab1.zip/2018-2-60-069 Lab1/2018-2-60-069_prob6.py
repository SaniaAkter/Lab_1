# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 21:30:24 2021

@author: supty
"""

def Fibonacci(n):
    if n<= 0:
        print("Incorrect input")

    elif n == 1:
        return 0

    elif n == 2:
        return 1
    else:
        return Fibonacci(n-1)+Fibonacci(n-2)
 
n = int(input("Enter the number : "))
 
print(Fibonacci(n)) 


 