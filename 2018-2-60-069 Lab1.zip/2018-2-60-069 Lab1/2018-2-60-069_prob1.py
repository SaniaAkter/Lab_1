# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

n1 = int(input("Enter a number: "))

n2 = int(input("Enter another number: "))

prod = n1*n2

if prod > 1000:

 print(n1+n2)

else:

 print(prod)