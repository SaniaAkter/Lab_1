# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 20:10:57 2021

@author: supty
"""

r=float(input("Input the Radius : "))
area=3.14*r*r
perimeter=2*3.14*r
print("Area of a Circle: ",area)
print("Perimeter of a Circle: ",perimeter)