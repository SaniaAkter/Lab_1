# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 20:16:35 2021

@author: supty
"""

def compound_interest_2018_2_60_126 (principle, rate, time):
    result = principle * (pow((1 + rate / 100), time))
    return result


p = float(input("Enter the principal amount: "))
r = float(input("Enter the interest rate: "))
t = float(input("Enter the time in years: "))

amount = compound_interest_2018_2_60_126 (p, r, t)
interest = amount - p
print("Compound amount is %.2f" % amount)
print("Compound interest is %.2f" % interest)