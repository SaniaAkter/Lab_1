# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 20:47:56 2021

@author: supty
"""

prime_find_2018_2_60_126 = int(input("Enter a positive integer number to check whether it is prime or not:"))
if prime_find_2018_2_60_126  > 1:
 
    for i in range(2, prime_find_2018_2_60_126 ):
 
    
        if (prime_find_2018_2_60_126  % i) == 0:
            print(prime_find_2018_2_60_126 , "is not a prime number") 
            break
    else:
        print(prime_find_2018_2_60_126 , "is a prime number") 
 
else:
    print(prime_find_2018_2_60_126 , "is not a prime number")  
    
    
    
        