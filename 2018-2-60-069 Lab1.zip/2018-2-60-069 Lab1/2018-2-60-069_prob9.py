# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 22:34:04 2021

@author: supty
"""
list = [10, 20, 4, 45, 99]
 
list.sort()
 
print("Second largest element is:", list[-2]) 